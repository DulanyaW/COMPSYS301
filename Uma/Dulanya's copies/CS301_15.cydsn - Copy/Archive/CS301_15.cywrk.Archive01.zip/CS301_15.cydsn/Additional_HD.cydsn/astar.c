/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#include <stdio.h>
#include <string.h>
#define MAP_ROW 15
#define MAP_COLOUMN 19


typeof struck


int matrix[MAP_ROW][MAP_COLOUMN] = {};
int directions [] = [(-1, 0); (1, 0); (0, -1); (0, 1)];  

int openset [] = {};

int wStartToEnd [] = {};
int wStartToEnd [MAP_ROW][MAP_COLOUMN] = {};




int main() {
    // Write C code here
    printf("Hello world");

    return 0;
}









/* [] END OF FILE */
